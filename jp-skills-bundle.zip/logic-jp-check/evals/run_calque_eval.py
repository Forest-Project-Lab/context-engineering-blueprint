#!/usr/bin/env python3
"""
run_calque_eval.py — カルク検出の「最小×最高精度」コンテキストを*探索*するハーネス。

目的: 候補となるコンテキスト断片(設定 A..E)それぞれを独立した分類器に与え、
ラベル付きセット上で TP/FN/FP/TN を実測し、precision/recall/F1 とサイズを並べる。
辞書順最適化（まず精度、次にサイズ）の勝者をデータで選ぶための道具。

使い方:
  pip install anthropic
  export ANTHROPIC_API_KEY=sk-...
  python run_calque_eval.py --eval calque_eval_set.json --trials 3 --model claude-haiku-4-5-20251001

注意: 判定器は会話本体の Claude とは別プロセス（毎回まっさら）。本人バイアスを避けるための設計。
"""
import argparse, json, os, sys, statistics
from collections import defaultdict

try:
    from anthropic import Anthropic
except ImportError:
    sys.exit("pip install anthropic が必要です。")

# --- 候補コンテキスト（ここが探索対象）。差分が分かるよう積み増しで定義 ---
RULE_R0 = "怪しい箇所を英語に戻し、きれいな英語に戻ればカルク（訳語臭）と判定する。"
RULE_R1 = ("怪しい箇所を英語に戻し、英語の慣用句・固定表現・有標な構文にそのまま戻って、"
           "その形のまま日本語になっていればカルク。ただし、単に文法的な普通の文に戻るだけ"
           "（例:「私は学生です」→I am a student）はカルクではない。")
SEED_L  = "また、英単語の一語訳もカルク。単語は慣用句でないので上の逆翻訳に掛かりにくい（status→地位, authority→権威, native→ネイティブに 等）。辞書一番目の訳を疑う。"
EXCL_X  = "ただし日本語に定着した借用語（データ・リスク・ストレス等）と、普通の否定文（「これは問題ではない」）はカルクではない。"
SEED_S  = "「XはYではない」式の警句や「〜することで」の多用もカルク。"
SEED_M  = "比喩の直訳（hammer→物量で押す, feeling blue→落ち込む）もカルク。"

CONFIGS = {
    "A: R0 素朴ルール":            RULE_R0,
    "B: R1 鋭いルール":            RULE_R1,
    "C: R1+L 語彙":               RULE_R1 + SEED_L,
    "D: R1+L+X 除外":             RULE_R1 + SEED_L + EXCL_X,
    "E: R1+L+X+S+M 全部":         RULE_R1 + SEED_L + EXCL_X + SEED_S + SEED_M,
}

SYS_TMPL = ("あなたはカルク（英語をなぞった不自然な日本語）の検出器です。次の基準のみを使うこと:\n"
            "---\n{snippet}\n---\n"
            "与えられた日本語の文1つについて、カルクなら CALQUE、自然な日本語なら OK と"
            "1語だけ返す。説明は不要。")

def classify(client, model, snippet, sentence):
    msg = client.messages.create(
        model=model, max_tokens=5,
        system=SYS_TMPL.format(snippet=snippet),
        messages=[{"role": "user", "content": sentence}],
    )
    out = "".join(b.text for b in msg.content if b.type == "text").strip().upper()
    return "CALQUE" if "CALQUE" in out else "OK"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--eval", default="calque_eval_set.json")
    ap.add_argument("--trials", type=int, default=3)
    ap.add_argument("--model", default="claude-haiku-4-5-20251001")
    args = ap.parse_args()

    items = json.load(open(args.eval, encoding="utf-8"))["items"]
    client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

    rows = []
    for name, snippet in CONFIGS.items():
        tp = fn = fp = tn = 0
        per_item_fp = []  # 擬陽性を出した陰性を記録（どこで誤るか可視化）
        for it in items:
            gold_pos = it["label"] == "calque"
            # trials 回投げて多数決（分類器の分散をならす）
            votes = [classify(client, args.model, snippet, it["text"]) for _ in range(args.trials)]
            pred_pos = votes.count("CALQUE") > args.trials / 2
            if gold_pos and pred_pos: tp += 1
            elif gold_pos and not pred_pos: fn += 1
            elif (not gold_pos) and pred_pos: fp += 1; per_item_fp.append(it["id"])
            else: tn += 1
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
        rows.append((name, tp, fn, fp, tn, prec, rec, f1, len(snippet), per_item_fp))

    # 辞書順: F1 降順 → サイズ昇順
    rows.sort(key=lambda r: (-r[7], r[8]))
    print(f"\n{'設定':<22}{'TP':>3}{'FN':>3}{'FP':>3}{'TN':>3}{'Prec':>7}{'Rec':>7}{'F1':>7}{'文字数':>7}  擬陽性箇所")
    print("-" * 86)
    for n, tp, fn, fp, tn, p, r, f, sz, fps in rows:
        print(f"{n:<22}{tp:>3}{fn:>3}{fp:>3}{tn:>3}{p:>7.2f}{r:>7.2f}{f:>7.2f}{sz:>7}  {','.join(fps) or '-'}")
    print("\n勝者 = F1最大かつ最小文字数の設定（上端）。"
          "FP列が0でない設定は擬陽性が残っている。サイズが大きいだけで精度が上がらない設定は棄却。")

if __name__ == "__main__":
    main()
